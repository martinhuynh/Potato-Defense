﻿using System;
public class PlayerStats
{
    public static float movementSpeed = 1.0f;
    public static float plowSpeed = 1.0f;
    public static float harvestSpeed = 1.0f;
    public static float attackPower = 1.0f;

    public PlayerStats()
    {
    }
}
